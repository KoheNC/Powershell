$computers = Import-Csv -Path .\computer.csv -Delimiter ';'
ForEach($computer in $computers){
    $name = "\\"+ $computer.name
    .\psgetsid.exe $name | Out-File .\results.txt -Append
}